import CarouselSlider from "./CarouselSlider";

export function Skills()
{
    return(
        <>
            <div id="skills">
                <h1>My Technical Skills</h1>
                <CarouselSlider/>
            </div>
        </>
    );
}